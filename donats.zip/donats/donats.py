from flask import Flask, render_template, redirect, session, make_response, request, url_for
from data import db_session
from data.loginform import LoginForm
from data.register import RegisterForm
from data.users import User
from flask_login import LoginManager
from flask_login import login_user, logout_user, login_required, current_user
import requests
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/')
@app.route('/index')
def index():
    param = {}
    param['username'] = "дорогие покупатели"
    param['title'] = 'Домашняя страница'
    return render_template('index.html', **param)


@app.route('/index_1')
def index_1():
    param = {}
    param['username'] = "дорогие покупатели"
    param['title'] = 'Домашняя страница'
    return render_template('index_1.html', **param)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        session = db_session.create_session()
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data)
        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/reg')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/reg')
def reg():
    param = {}
    param['username'] = "Регистрация прошла успешно"
    param['title'] = 'Авторизация'
    return render_template('reg.html', **param)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/menu")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/menu')
def library():
    param = {}
    param['title'] = 'Лучшее меню'
    return render_template('menu.html', **param)


@app.route('/donats')
def klass5():
    param = {}
    param['username'] = 'дорогой покупатель'
    param['title'] = 'Меню самых вкусных пончиков'
    return render_template('choko.html', **param)


@app.route('/choko')
def choko():
    param = {}
    param['username'] = 'дорогой покупатель'
    param['title'] = 'Все о шоколадном'
    return render_template('choko.html', **param)


@app.route('/strob')
def strob():
    param = {}
    param['username'] = 'дорогой покупатель'
    param['title'] = 'Все о клубничном'
    return render_template('strob.html', **param)


@app.route('/banana')
def banana():
    param = {}
    param['username'] = 'дорогой покупатель'
    param['title'] = 'Все о банановом'
    return render_template('banana.html', **param)


def main():
    db_session.global_init("db/mars_explorer.db")

    app.run()


if __name__ == '__main__':
    main()
